package com.mortgage;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class LoanService {

	@Autowired
	LoanRepository loanRepository;

	public String applyloan(Loan loan) {
		String res = "";
		Loan loan2 = loanRepository.getLoanByPropertyid(loan.getPropertyid());
		System.out.println("property details" + loan2);
		if (loan2 == null) {
			if (loan.getResidence().toLowerCase().equals("india")) {
				if (loan.getCreditscore() < 1000) {
					if (loan.getCreditscore() > 500) {
						if (loan.getAreacode() > 0 && loan.getAreacode() <= 300) {
							System.out.println("service" + loan);
							Loan loan3 = loanRepository.save(loan);
							if (loan3 != null) {
								res = "Loan Applied";
							} else {
								res = "Loan Details are not perfect";
							}
						} else {
							res = "area code is out of range";
						}

					} else {
						res = "Credit Score Should Not be less than 500";
					}
				} else {
					res = "Credit Score Should Not be Greater than 1000";
				}
			} else {
				res = "Not A Legal Residence";
			}
		} else {
			res = "Loan cannot be applied on same property";
		}
		return res;
	}

	public List<Loan> getloans(int id) {
		return loanRepository.getLoanByid(id);
	}

	public int loanAmount(int loanid) {
		Loan loan = loanRepository.getLoanByLoanid(loanid);
		int areacode = loan.getAreacode();
		int sqrate = 0;
		int loanamount = 0;
		if (areacode > 0 && areacode <= 100) {
			sqrate = 3000;
		}
		if (areacode > 100 && areacode <= 200) {
			sqrate = 1000;
		}
		if (areacode > 200 && areacode <= 300) {
			sqrate = 2000;
		}
		loanamount =  (int) ((sqrate * loan.getPropertysq()) * 0.7);
		return loanamount;
	}
}
